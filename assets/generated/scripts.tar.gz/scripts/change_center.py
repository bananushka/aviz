#!/usr/bin/env python
from aviz_framework import run


def change_center(line, x, y, z):
    line.x -= x
    line.y -= y
    line.z -= z
    return line


def manipulate(aviz_file, **kwargs):
    aviz_file.atoms = [change_center(line, **kwargs)
                       for line in aviz_file]
    return aviz_file


def build_parser(parser):
    default_0 = '0 by default'
    parser.add_argument('-x', type=float, default=0.0, help=default_0)
    parser.add_argument('-y', type=float, default=0.0, help=default_0)
    parser.add_argument('-z', type=float, default=0.0, help=default_0)
    return parser


if __name__ == '__main__':
    run(manipulate, build_parser)
