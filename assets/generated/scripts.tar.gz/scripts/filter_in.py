#!/usr/bin/env python
from aviz_framework import run


def inBounds(side, line):
    return all([abs(coord) <= side
                for coord in line.coords()])


def manipulate(aviz_file, side):
    aviz_file.atoms = [line for line in aviz_file
                       if inBounds(side, line)]
    return aviz_file


def build_parser(parser):
    parser.add_argument('-s', '--side', required=True, type=float)
    return parser


if __name__ == '__main__':
    run(manipulate, build_parser)
