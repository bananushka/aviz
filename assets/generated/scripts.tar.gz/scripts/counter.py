#!/usr/bin/env python
from aviz_framework import run
import attr
from attr.validators import instance_of


@attr.s(repr=False)
class Range(object):
    start = attr.ib(validator=instance_of(float))
    end = attr.ib(validator=instance_of(float))

    def __repr__(self):
        return '%s -> %s' % (str(self.start), str(self.end))


@attr.s(repr=False)
class Counters(object):
    atoms = attr.ib(validator=instance_of(list))
    x = attr.ib(validator=instance_of(Range))
    y = attr.ib(validator=instance_of(Range))
    z = attr.ib(validator=instance_of(Range))

    @classmethod
    def from_aviz_file(cls, aviz_file):
        atoms = cls.get_atoms(aviz_file)
        x = cls.get_x_range(aviz_file)
        y = cls.get_y_range(aviz_file)
        z = cls.get_z_range(aviz_file)

        return cls(atoms, x, y, z)

    @classmethod
    def get_atoms(cls, aviz_file):
        atoms = set()
        for line in aviz_file:
            atoms.add(line.atom)

        return list(atoms)

    @classmethod
    def get_x_range(cls, aviz_file):
        return cls.get_range([line.x for line in aviz_file])

    @classmethod
    def get_y_range(cls, aviz_file):
        return cls.get_range([line.y for line in aviz_file])

    @classmethod
    def get_z_range(cls, aviz_file):
        return cls.get_range([line.z for line in aviz_file])

    @classmethod
    def get_range(cls, coords):
        return Range(min(coords), max(coords))

    def __repr__(self):
        output = []

        atoms = ', '.join(self.atoms)
        output.append('Atoms:\t%s' % atoms)

        output.append('X:\t%s' % repr(self.x))
        output.append('Y:\t%s' % repr(self.y))
        output.append('Z:\t%s' % repr(self.z))

        output.append('')
        return '\n'.join(output)


def manipulate(aviz_file):
    return Counters.from_aviz_file(aviz_file)


if __name__ == '__main__':
    run(manipulate)
