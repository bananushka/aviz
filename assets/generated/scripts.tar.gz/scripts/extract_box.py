#!/usr/bin/env python
from aviz_framework import run
import change_center
import filter_in


def manipulate(aviz_file, recenter, side, **coords):
    result = filter_in.manipulate(change_center.manipulate(aviz_file, **coords), side)
    if not recenter:
        result = change_center.manipulate(result, **{coord: -value for coord, value in coords.iteritems()})
    return result


def build_parser(parser):
    parser.add_argument('--recenter', dest='recenter', action='store_true', help='by default, true')
    parser.add_argument('--no-recenter', dest='recenter', action='store_false', help='keep atoms in original positions')
    parser.set_defaults(recenter=True)
    return parser


if __name__ == '__main__':
    run(manipulate, change_center.build_parser, filter_in.build_parser, build_parser)
