import attr
import re
from attr.validators import instance_of

@attr.s(repr=False)
class AVizFile(object):
    file = attr.ib(validator=instance_of(file))

    def __enter__(self):
        self.file.__enter__()
        self.lines = [line.strip() for line in self.file if len(line.strip()) > 0]
        self.comment = self.lines[1]
        self.atoms = self.build_atoms()
        return self

    def build_atoms(self):
        return [self.build_atom(line) for line in self.lines[2:]]


    def build_atom(self, line):
        return AVizLine.from_str(line)

    def __exit__(self, *args):
        self.file.__exit__(*args)

    def __iter__(self):
        for atom in self.atoms:
            yield atom

    def __repr__(self):
        result = ''
        result += ' %d' % len(self.atoms)
        result += '\n%s\n' % self.comment
        result += '\n'.join([repr(line) for line in self.atoms])
        result += '\n'
        return result

@attr.s(repr=False)
class AVizLine(object):
    atom = attr.ib(validator=instance_of(str))
    x = attr.ib(validator=instance_of(float))
    y = attr.ib(validator=instance_of(float))
    z = attr.ib(validator=instance_of(float))

    @classmethod
    def from_str(cls, string):
        fields = re.split(r'\s+', string)
        atom = fields[0]
        [x, y, z] = [float(coord) for coord in fields[1:4]]
        return cls(atom=atom, x=x, y=y, z=z)

    def coords(self):
        return [self.x, self.y, self.z]

    def __repr__(self):
        return '%s %f %f %f' % (self.atom, self.x, self.y, self.z)

