#!/usr/bin/env python
from aviz_framework import run


def manipulate(aviz_file, atom):
    aviz_file.atoms = [line for line in aviz_file
                       if line.atom in atom]
    return aviz_file


def build_parser(parser):
    parser.add_argument('-a', '--atom', required=True, action='append',
                        help='could be used multiple times (to keep more than one atom)')
    return parser


if __name__ == '__main__':
    run(manipulate, build_parser)
