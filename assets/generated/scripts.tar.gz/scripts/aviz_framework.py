from aviz import AVizFile
import sys
import argparse


def default_parser():
    parser = argparse.ArgumentParser()
    parser.add_argument('input_file', nargs='?', type=argparse.FileType('r'),
                        default=sys.stdin,
                        help='by default, reads from stdin')
    parser.add_argument('output_file', nargs='?', type=argparse.FileType('w'),
                        default=sys.stdout,
                        help='by default, writes to stdout  ')
    return parser


def run(callback, *parser_builders):
    parser = default_parser()
    for parser_builder in parser_builders:
        parser = parser_builder(parser)

    unparsed_arguments = sys.argv[1:]
    arguments = parser.parse_args(unparsed_arguments)
    kwargs = {key: value
               for key, value in vars(arguments).items()
               if value is not None
                    and key not in ('input_file', 'output_file')}

    with AVizFile(arguments.input_file) as aviz_file:
        representable = callback(aviz_file, **kwargs)
        with arguments.output_file as output:
            output.write(repr(representable))
